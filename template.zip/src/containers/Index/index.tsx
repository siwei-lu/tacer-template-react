import React from 'react'
import styled from 'styled-components'
import Welcome from './Welcome'

export default function() {
  return (
    <Container>
      <Welcome />
    </Container>
  )
}

export const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
`
