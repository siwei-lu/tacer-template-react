import React from 'react'
import { render, fireEvent } from '@testing-library/react'
import Like from '../Like'

test('should render with a given count', () => {
  const { getByText } = render(<Like count={5} />)
  expect(getByText('5')).not.toBeNull()
})

test('should call the given callback when clicked', () => {
  const onClick = jest.fn()
  const { getByText } = render(<Like count={5} onClick={onClick} />)

  const container = getByText('5')
  fireEvent.click(container)
  expect(onClick).toBeCalledWith(6)
})
