import React from 'react'
import styled from 'styled-components'

type Props = {
  count: number
  onClick?: (count: number) => void
}

export default function Like({ count, onClick }: Props) {
  const handleClick = () => {
    onClick && onClick(count + 1)
  }

  return <Container onClick={handleClick}>{count}</Container>
}

export const Container = styled.button``
